create sequence application_id_seq start with 1000;

create sequence roll_no_seq start with 16000;

desc Users;
create table Users(login_id varchar2(5),
user_password varchar2(10),
user_role varchar2(5));




desc Participant;
create table Participant ( Roll_no varchar2(5),
email varchar2(20),
applicationid references applicant(applicationid) ,
scheduledprogramid varchar2(5));


desc Programs_Scheduled;
create table	Programs_Scheduled ( scheduledprogramid varchar2(5),
 ProgramName varchar2(5),
 program_location varchar2(10),
 start_date date,
 end_date date,
 sessions_per_week number);
 
 desc Programs_Offered;/
create table	Programs_Offered( ProgramName varchar2(5),
 description varchar2(20),
 applicant_eligibility varchar2(40) ,
 program_duration number, 
 degree_certificate_offered varchar2(10));
 
 
desc applicant;
create table applicant (applicationid number primary key,
 fullname varchar2(20),
 dateofbirth date,
 highestqualification varchar2(10),
 marksobtained number,
 goals varchar2(20),
 email varchar2(20),
 scheduledprogramid varchar2(5),
 status varchar2(10),
 dateofinterview date);

insert into Users values('IN100','capgemini','ADMIN');

delete from programs_offered where programname='ECE';

delete from participant where applicationid=1001;






select * from Users;

select * from programs_scheduled;

select * from programs_offered;

select * from applicant;

select * from participant;

select * from Users where login_id='IN100';

insert into Users values('IN101','capgemini1','MAC');

commit;





 select user_password,user_role from Users where login_id='IN101';